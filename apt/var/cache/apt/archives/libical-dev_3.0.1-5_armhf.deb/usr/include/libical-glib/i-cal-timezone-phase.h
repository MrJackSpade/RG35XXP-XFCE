/* Generated file (by generator) */

/*
 * Copyright (C) 2015 William Yu <williamyu@gnome.org>
 *
 * This library is free software: you can redistribute it and/or modify it
 * under the terms of version 2.1. of the GNU Lesser General Public License
 * as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License
 * for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library. If not, see <http://www.gnu.org/licenses/>.
 */

#if !defined (__LIBICAL_GLIB_H_INSIDE__) && !defined (LIBICAL_GLIB_COMPILATION)
#error "Only <libical-glib/libical-glib.h> can be included directly."
#endif

#ifndef I_CAL_TIMEZONE_PHASE_H
#define I_CAL_TIMEZONE_PHASE_H

#include <libical-glib/i-cal-forward-declarations.h>
#include <libical-glib/i-cal-timetype.h>
#include <libical-glib/i-cal-datetimeperiod-type.h>
#include <libical-glib/i-cal-object.h>

G_BEGIN_DECLS

#define I_CAL_TIMEZONE_PHASE_TYPE \
    (i_cal_timezone_phase_get_type ())

#define I_CAL_TIMEZONE_PHASE(obj) \
    (G_TYPE_CHECK_INSTANCE_CAST \
    ((obj), I_CAL_TIMEZONE_PHASE_TYPE, ICalTimezonePhase))

#define I_CAL_TIMEZONE_PHASE_CLASS(klass) \
    (G_TYPE_CHECK_CLASS_CAST \
    ((klass), I_CAL_TIMEZONE_PHASE_TYPE, ICalTimezonePhaseClass))

#define I_CAL_IS_TIMEZONE_PHASE(obj) \
    (G_TYPE_CHECK_INSTANCE_TYPE \
    ((obj), I_CAL_TIMEZONE_PHASE_TYPE))

#define I_CAL_IS_TIMEZONE_PHASE_CLASS(klass) \
    (G_TYPE_CHECK_CLASS_TYPE \
    ((klass), I_CAL_TIMEZONE_PHASE_TYPE))

/**
 * ICalTimezonePhase:
 *
 * This is the ICalTimezonePhase instance.
 */

/**
 * ICalTimezonePhaseClass:
 *
 * This is the ICalTimezonePhase class.
 */
typedef struct _ICalTimezonePhaseClass ICalTimezonePhaseClass;

struct _ICalTimezonePhase {
    /*< private >*/
    ICalObject parent;
};

struct _ICalTimezonePhaseClass {
    /*< private >*/
    ICalObjectClass parent;
};

LIBICAL_ICAL_EXPORT
GType 		i_cal_timezone_phase_get_type	(void);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_timezone_phase_get_tzname	(ICalTimezonePhase *phase);

LIBICAL_ICAL_EXPORT
gint 		i_cal_timezone_phase_is_stdandard
						(ICalTimezonePhase *phase);

LIBICAL_ICAL_EXPORT
void		i_cal_timezone_phase_set_is_stdandard
						(ICalTimezonePhase *phase,
						 gint is_stdandard);

LIBICAL_ICAL_EXPORT
ICalTimetype *	i_cal_timezone_phase_get_dtstart
						(ICalTimezonePhase *phase);

LIBICAL_ICAL_EXPORT
void		i_cal_timezone_phase_set_dtstart
						(ICalTimezonePhase *phase,
						 ICalTimetype *dtstart);

LIBICAL_ICAL_EXPORT
gint 		i_cal_timezone_phase_get_offsetto
						(ICalTimezonePhase *phase);

LIBICAL_ICAL_EXPORT
void		i_cal_timezone_phase_set_offsetto
						(ICalTimezonePhase *phase,
						 gint offsetto);

LIBICAL_ICAL_EXPORT
gint 		i_cal_timezone_phase_get_tzoffsetfrom
						(ICalTimezonePhase *phase);

LIBICAL_ICAL_EXPORT
void		i_cal_timezone_phase_set_tzoffsetfrom
						(ICalTimezonePhase *phase,
						 gint tzoffsetfrom);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_timezone_phase_get_comment
						(ICalTimezonePhase *phase);

LIBICAL_ICAL_EXPORT
ICalDatetimeperiodType *
		i_cal_timezone_phase_get_rdate	(ICalTimezonePhase *phase);

LIBICAL_ICAL_EXPORT
void		i_cal_timezone_phase_set_rdate	(ICalTimezonePhase *phase,
						 ICalDatetimeperiodType *rdate);

LIBICAL_ICAL_EXPORT
const gchar *	i_cal_timezone_phase_get_rrule	(ICalTimezonePhase *phase);

G_END_DECLS

#endif /* I_CAL_TIMEZONE_PHASE_H */

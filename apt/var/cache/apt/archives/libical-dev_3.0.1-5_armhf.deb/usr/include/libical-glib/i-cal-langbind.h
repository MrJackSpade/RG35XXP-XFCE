/* Generated file (by generator) */

/*
 * Copyright (C) 2015 William Yu <williamyu@gnome.org>
 *
 * This library is free software: you can redistribute it and/or modify it
 * under the terms of version 2.1. of the GNU Lesser General Public License
 * as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License
 * for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library. If not, see <http://www.gnu.org/licenses/>.
 */

#if !defined (__LIBICAL_GLIB_H_INSIDE__) && !defined (LIBICAL_GLIB_COMPILATION)
#error "Only <libical-glib/libical-glib.h> can be included directly."
#endif

#ifndef I_CAL_LANGBIND_H
#define I_CAL_LANGBIND_H

#include <libical-glib/i-cal-forward-declarations.h>
#include <libical-glib/i-cal-object.h>

G_BEGIN_DECLS


LIBICAL_ICAL_EXPORT
gint *		i_cal_langbind_new_array	(gint size);

LIBICAL_ICAL_EXPORT
void		i_cal_langbind_free_array	(gint *array);

LIBICAL_ICAL_EXPORT
gint 		i_cal_langbind_access_array	(gint *array,
						 gint index);

LIBICAL_ICAL_EXPORT
ICalParameter *	i_cal_langbind_get_first_parameter
						(ICalProperty *prop);

LIBICAL_ICAL_EXPORT
ICalParameter *	i_cal_langbind_get_next_parameter
						(ICalProperty *prop);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_langbind_get_first_property
						(ICalComponent *c,
						 const gchar *prop);

LIBICAL_ICAL_EXPORT
ICalProperty *	i_cal_langbind_get_next_property
						(ICalComponent *c,
						 const gchar *prop);

LIBICAL_ICAL_EXPORT
ICalComponent *	i_cal_langbind_get_first_component
						(ICalComponent *c,
						 const gchar *comp);

LIBICAL_ICAL_EXPORT
ICalComponent *	i_cal_langbind_get_next_component
						(ICalComponent *c,
						 const gchar *comp);

LIBICAL_ICAL_EXPORT
gchar *		i_cal_langbind_property_eval_string_r
						(ICalProperty *prop,
						 const gchar *sep);

LIBICAL_ICAL_EXPORT
gint 		i_cal_langbind_string_to_open_flag
						(const gchar *str);

LIBICAL_ICAL_EXPORT
gchar *		i_cal_langbind_quote_as_ical_r	(const gchar *str);

G_END_DECLS

#endif /* I_CAL_LANGBIND_H */

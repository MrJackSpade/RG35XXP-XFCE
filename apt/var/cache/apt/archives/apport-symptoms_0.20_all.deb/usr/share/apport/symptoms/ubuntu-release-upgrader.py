# ubuntu-release-upgrader related problems
# Author: Brian Murray <brian.murray@canonical.com>
# (C) 2013 Canonical Ltd.
# License: GPL v2 or later.


def run(report, ui):
    return 'ubuntu-release-upgrader-core'
